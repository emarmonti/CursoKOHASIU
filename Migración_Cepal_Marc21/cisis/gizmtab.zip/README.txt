Para serem usados tanto no modo de apresenta��o como para invers�o das bases

Tabelas de UPPER CASE e ASCII Valido

-ASCII CODE PAGE 437 (CP437)
ac437.tab Caracteres v�lidos do conjunto ASCII CP437
ac437n.tab Caracteres v�lidos do conjunto ASCII CP437 incl. 0-9
ac437XT.tab Caracteres v�lidos do conjunto ASCII CP437 incl. 0-9 e #&'-./:=?@_~
ac437UT.tab Caracteres v�lidos do conjunto ASCII CP437 incl. 0-9 e !#&',-./:;<=>?@\_`{}~
ma437.tab Convers�o dos caracteres para mai�sculas (com acento)
mi437.tab Convers�o dos caracteres para min�sculas (com acento)
na437.tab Elimina acentos dos caracteres, mantendo mai�sculas/min�sculas
uc437.tab Convers�o dos caracteres para mai�sculas (sem acentos)
lc437.tab Convers�o dos caracteres para min�sculas (sem acentos)

-ASCII CODE PAGE 850 (CP850)
ac850.tab Caracteres v�lidos do conjunto ASCII CP850
ac850n.tab Caracteres v�lidos do conjunto ASCII CP850 incl. 0-9
ac850XT.tab Caracteres v�lidos do conjunto ASCII CP850 incl. 0-9 e #&'-./:=?@_~
ac850UT.tab Caracteres v�lidos do conjunto ASCII CP850 incl. 0-9 e !#&',-./:;<=>?@\_`{}~��
ma850.tab Convers�o dos caracteres para mai�sculas (com acento)
mi850.tab Convers�o dos caracteres para min�sculas (com acento)
na850.tab Elimina acentos dos caracteres, mantendo mai�sculas/min�sculas
uc850.tab Convers�o dos caracteres para mai�sculas (sem acentos)
lc850.tab Convers�o dos caracteres para min�sculas (sem acentos)

-ANSI (Windows)
acans.tab Caracteres v�lidos do conjunto ANSI
acansn.tab Caracteres v�lidos do conjunto ANSI incl. 0-9
acansXT.tab Caracteres v�lidos do conjunto ANSI incl. 0-9 e #&'-./:=?@_~
acansUT.tab Caracteres v�lidos do conjunto ANSI incl. 0-9 e !#&',-./:;<=>?@\_`{}~��
maans.tab Convers�o dos caracteres para mai�sculas (com acento)
mians.tab Convers�o dos caracteres para min�sculas (com acento)
naans.tab Elimina acentos dos caracteres, mantendo ma�sculas/min�sculas
ucans.tab Convers�o dos caracteres para mai�sculas (sem acentos)
lcans.tab Convers�o dos caracteres para min�sculas (sem acentos)

Toda e qualquer tabela tem 32 elementos de largura com um espa�o de separa��o
Todas as linhas devem ser temrinadas por CR+LF (DOS) ou LF (Unix/Linux)


GIZMOs dispon�veis para convers�o do conte�do de bases de dados

-Convers�o do conjunto de caracteres
g437ans  Convers�o de ASCII CODE PAGE 437 para ANSI
gans437  Convers�o de ANSI para ASCII CODE PAGE 437
g850ans  Convers�o de ASCII CODE PAGE 850 para ANSI
gans850  Convers�o de ANSI para ASCII CODE PAGE 850
gutf8850 Conversao de UTF-8 para ASCII CODE PAGE 850
gutf8ans Convers�o de UTF-8 para ANSI
g437utf8 Conversao de ASCII CODE PAGE 437 para UTF-8
g850utf8 Conversao de ASCII CODE PAGE 850 para UTF-8
gansutf8 Convers�o de ANSI para UFT-8

-ASCII CODE PAGE 437 (CP437)
g437ma Convers�o para mai�sculas acentuadas
g437mi Convers�o para min�sculas acentuadas
g437na Retira acentos mantendo mai�sculas/min�sculas
g437uc Convers�o para mai�sculas sem acento (Upper case)
g437lc Convers�o para min�sculas sem acento (Lower case)

-ASCII CODE PAGE 850 (CP850)
g850ma Convers�o para mai�sculas acentuadas
g850mi Convers�o para min�sculas acentuadas
g850na Retira acentos mantendo mai�sculas/min�sculas
g850uc Convers�o para mai�sculas sem acento (Upper case)
g850lc Convers�o para min�sculas sem acento (Lower case)

-ANSI (Windows)
gansma Convers�o para mai�sculas acentuadas
gansmi Convers�o para min�sculas acentuadas
gansna Retira acentos mantendo mai�sculas/min�sculas
gansuc Convers�o para mai�sculas sem acento (Upper case)
ganslc Convers�o para min�sculas sem acento (Lower case)

-Convers�o auxiliar de caracteres de marca��o
gentit   Convers�o de caracteres pela entidade HTML correspondente ("&'<>)
gcharent Convers�o de caracteres pela entidade HTML correspondente ("&'<>)
gchar    Convers�o para a entidade HTML pelos caracteres correspondentes ("&'<>)
gentchar Convers�o para a entidade HTML pelos caracteres correspondentes ("&'<>)
gentHex  Conversao para c�digo Hexadecimal (notacao URL) dos caracteres "&'<>

-Eliminacao de caracteres de controle
gclean Elimina caracteres com c�digo abaixo de 32 (0x20)

-Convers�o auxiliar de e para entidades HTML
ghtmlans Converte entidades HTML em caracteres ANSI
ganshtml Converte caracteres ANSI em entidades HTML
ghtml850 Converte entidades HTML em caracteres ASCII CP850
g850html Converte caracteres ASCII CP850 em entidades HTML
ghtml437 Converte entidades HTML em caracteres ASCII CP437
g437html Converte caracteres ASCII CP437 em entidades HTML


Nas bases gizmo o campo 59 do primeiro registro define a vers�o do gizmo

Os campos tem as seguintes fun��es:
001 | Codica��o do caractere procurado
002 | Codifica��o do caractere substituto
011 | especificacao do codigo do campo 1 (asc / hex / ...)
021 | especificacao do codigo do campo 2 (asc / hex / ...)
041 | entidade html numerica da representa��o do caractere
042 | entidade html textual da representa��o do caractere
050 | Coment�rio sobre o elemento sendo operado neste registro
051 | Coment�rio sobre o elemento sendo operado neste registro (normalmente em portugues)
052 | Coment�rio sobre o elemento sendo operado neste registro (normalmente em ingles)
059 | Indicador de vers�o


Como reconhecer o conjunto de caracteres em que est� uma base CDS/ISIS
-Se na distribui��o de caracteres oferecida pelo MXF0 houver AUSENCIA de caracteres
com c�digos entre 127(0x7f) e 159(0x9f) (inclusive), ent�o pertencem ao conjunto ANSI.
-Se na distribui��o de caracteres oferecida pelo MXF0 houver uma forte concentra��o
entre os c�digos 128(0x80) at� 167(0xa7) (inclusive) � muito prov�vel que seja Code Page 437.
-Se na distribui��o de caracteres oferecida pelo MXF0 houver presen�a de elementos em
algum dos seguintes c�digos: 181(0xb5), 182, 183, 198, 199, 210, 211, 212, 214, 215, 216,
222, 224, 226, 227, 228, 229, 233, 234, 235, 236, 237 � muito prov�vel que seja Code Page 850.

� importante a presen�a como caracteres discriminadores do c�digo de p�gina: o
198(0xc6) e 199(0xc6), que s�o � e �, e tamb�m 228(0xe4) e 229(0xe5) que s�o � e �.
! Os caracteres 198 e 199 dos conjuntos ANSI e ASCII
850 s�o imprim�veis, sendo � (AElig) e � em ANSI
e � e � em ASC850, al�m destes 228 e 229 tamb�m
s�o imprim�veis, sendo � e � (Aring) em ANSI e � e � em ASCII-850.

Elemento de complica��o: Windows 95 e 98 utilizam codifica��o diferente de
Windows 98SE e posteriores.
OBSERVA��ES
Os gizmos de convers�o entre os conjuntos de caracteres: ANSI; ASCII CP437; e ASCII CP850,
t�m como objetivo obter caracteres gr�ficos similares.
Os gizmos de CONVERS�O AUXILIAR abrangem s� os caracteres acentuados.
